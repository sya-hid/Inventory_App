package com.syarifhidayatullah.myapplication.Base

interface BasePresenter {
    fun subscribe()
    fun unsubscribe()
}