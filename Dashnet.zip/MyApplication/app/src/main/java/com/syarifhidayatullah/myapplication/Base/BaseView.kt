package com.syarifhidayatullah.myapplication.Base

interface BaseView {
    fun showLoading()
    fun dismissLoading()
}