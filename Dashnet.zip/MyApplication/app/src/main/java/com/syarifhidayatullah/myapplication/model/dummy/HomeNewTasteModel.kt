package com.syarifhidayatullah.myapplication.model.dummy

class HomeNewTasteModel (title:String, src:String, price:String,rating:Float) {
    var title=""
    var src =""
    var price =""
    var rating=0f

    init {

        this.title=title
        this.src=src
        this.price=price
        this.rating=rating
    }

}