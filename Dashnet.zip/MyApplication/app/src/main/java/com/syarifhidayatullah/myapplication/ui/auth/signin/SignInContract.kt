package com.syarifhidayatullah.myapplication.ui.auth.signin


import com.syarifhidayatullah.myapplication.Base.BasePresenter
import com.syarifhidayatullah.myapplication.Base.BaseView
import com.syarifhidayatullah.myapplication.model.response.login.LoginResponse

interface SignInContract {
    interface View : BaseView {
        fun onLoginSuccess(loginResponse: LoginResponse)
        fun onLoginFailed(message: String)
    }

    interface Presenter : SignInContract, BasePresenter {
        fun submitLogin(email: String, password: String)
    }
}