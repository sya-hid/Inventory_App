package com.syarifhidayatullah.myapplication.ui.detail

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.os.bundleOf
import androidx.navigation.Navigation
import com.bumptech.glide.Glide
import com.syarifhidayatullah.myapplication.R
import com.syarifhidayatullah.myapplication.model.response.home.Data
import com.syarifhidayatullah.myapplication.utils.Helpers.formatPrice
import kotlinx.android.synthetic.main.fragment_detail.*


class DetailFragment : Fragment() {

    var bundle: Bundle? = null
    var data: Data? = null
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val root = inflater.inflate(R.layout.fragment_detail, container, false)
        return root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        (activity as DetailActivity).toolbarDetail()
        var data = arguments?.getParcelable<Data>("data")
        initView(data)
//        arguments?.let {
//            DetailFragmentArgs.fromBundle(it).data.let {
//                initView(it)
//            }
//        }
        btnOrderNow.setOnClickListener {view ->
            Navigation.findNavController(view).navigate(R.id.action_payment, bundle)
        }
    }

    private fun initView(data: Data?) {

        Glide.with(requireActivity())
            .load(data?.gambar_produk)
            .into(imageView2)
    //    rbFood.rating = data?.rate?.toFloat() ?: 0f
        txvTittle.text = data?.nama_produk
        txvDesc.text = data?.kd_kategori
     //   txvIngredient.text = data?.ingredients
//        if (data != null) {
//            txvPrice.formatPrice(data.price.toString())
//        }
        bundle = bundleOf("data" to data)
    }

}