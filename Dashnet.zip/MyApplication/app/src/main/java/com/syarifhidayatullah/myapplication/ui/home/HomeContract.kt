package com.syarifhidayatullah.myapplication.ui.home

import com.syarifhidayatullah.myapplication.model.response.login.LoginResponse
import com.syarifhidayatullah.myapplication.Base.BasePresenter
import com.syarifhidayatullah.myapplication.Base.BaseView
import com.syarifhidayatullah.myapplication.model.response.home.HomeResponse

interface HomeContract {
    interface View : BaseView {
        fun onHomeSuccess(homeResponse: HomeResponse)
        fun onHomeFailed(message: String)
    }

    interface Presenter : HomeContract, BasePresenter {
        fun getHome()
    }
}