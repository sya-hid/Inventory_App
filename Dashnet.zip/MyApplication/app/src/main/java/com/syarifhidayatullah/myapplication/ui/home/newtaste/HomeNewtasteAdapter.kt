package com.syarifhidayatullah.myapplication.ui.home.newtaste

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.syarifhidayatullah.myapplication.R
import com.syarifhidayatullah.myapplication.model.dummy.HomeModel
import com.syarifhidayatullah.myapplication.model.dummy.HomeNewTasteModel
import com.syarifhidayatullah.myapplication.utils.Helpers.formatPrice
import kotlinx.android.synthetic.main.item_home_horizontal.view.rbFood
import kotlinx.android.synthetic.main.item_home_horizontal.view.txvTittle
import kotlinx.android.synthetic.main.item_home_vertical.view.*

class HomeNewtasteAdapter(
    private val listData: List<HomeNewTasteModel>,
    private val itemAdapterCallback: ItemAdapterCallback
) : RecyclerView.Adapter<HomeNewtasteAdapter.ViewHolder>() {
    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): HomeNewtasteAdapter.ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view = layoutInflater.inflate(R.layout.item_home_vertical, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return listData.size
    }

    override fun onBindViewHolder(holder: HomeNewtasteAdapter.ViewHolder, position: Int) {
        holder.bind(listData[position], itemAdapterCallback)
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(data: HomeNewTasteModel, itemAdapterCallback: ItemAdapterCallback) {
            itemView.apply {
                txvTittle.text = data.title
           //     txvPrice.formatPrice(data.price.toString())
                rbFood.rating = data.rating?.toFloat() ?: 0f
//                Glide.with(context)
//                    .load(data.src)
//                    .into(imvPoster2)
                itemView.setOnClickListener { itemAdapterCallback.onClick(it, data) }
            }
        }
    }

    interface ItemAdapterCallback {
        fun onClick(v: View, data: HomeNewTasteModel)
    }
}