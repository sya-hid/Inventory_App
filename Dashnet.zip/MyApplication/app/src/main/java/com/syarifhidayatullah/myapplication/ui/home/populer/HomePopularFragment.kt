package com.syarifhidayatullah.foodmarketkotlin.ui.home.populer

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.syarifhidayatullah.myapplication.R
import com.syarifhidayatullah.myapplication.model.dummy.HomeNewTasteModel
import com.syarifhidayatullah.myapplication.ui.detail.DetailActivity
import com.syarifhidayatullah.myapplication.ui.home.newtaste.HomeNewtasteAdapter
import kotlinx.android.synthetic.main.fragment_home_new_taste.*

class HomePopularFragment : Fragment(), HomeNewtasteAdapter.ItemAdapterCallback {

    private var footList: ArrayList<HomeNewTasteModel> = ArrayList()
    private var popularList: ArrayList<HomeNewTasteModel>? = ArrayList()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val root=inflater.inflate(R.layout.fragment_home_new_taste, container, false)
        return root

    }
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

  //      popularList=arguments?.getParcelableArrayList("data")
          initDataDummy()
        var adapter= HomeNewtasteAdapter(footList,this)
        var layoutManager: RecyclerView.LayoutManager=
            LinearLayoutManager(activity)
        rcvFoodList.layoutManager=layoutManager
        rcvFoodList.adapter=adapter




    }
    fun initDataDummy() {
        footList= ArrayList()
        footList.add(HomeNewTasteModel("Cherry Healthy","","10000",5f))
        footList.add(HomeNewTasteModel("Cherry Healthy","","10000",3.5f))
        footList.add(HomeNewTasteModel("Cherry Healthy","","10000",4.5f))
    }
    override fun onClick(v: View, data: HomeNewTasteModel) {
        //val detail= Intent(activity, DetailActivity::class.java)
//        .putExtra("data",data)
      //  startActivity(detail)
    Toast.makeText(context,""+data.title, Toast.LENGTH_LONG).show()

    }
}