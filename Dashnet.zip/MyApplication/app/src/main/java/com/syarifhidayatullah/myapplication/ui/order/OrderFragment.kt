package com.syarifhidayatullah.myapplication.ui.order

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.syarifhidayatullah.myapplication.R

import kotlinx.android.synthetic.main.fragment_order.*
import kotlinx.android.synthetic.main.layout_toolbar.view.*

class OrderFragment : Fragment() {
    lateinit var presenter: OrderPresenter
    var progressDialog: Dialog? = null

  // var inProgressList: ArrayList<Data>? = ArrayList()
//    var pastOrderList: ArrayList<Data>? = ArrayList()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val root = inflater.inflate(R.layout.fragment_order, container, false)
        return root

    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        initView()
                    layout_empty_order.visibility = View.GONE
            layout_order.visibility = View.VISIBLE
            include_toolbar.visibility = View.VISIBLE

//        presenter = OrderPresenter(this)
//        presenter.getTransaction()
    }

    private fun initView() {
        progressDialog = Dialog(requireContext())
        val dialogLayout = layoutInflater.inflate(R.layout.dialog_loader, null)

        progressDialog?.let {
            it.setContentView(dialogLayout)
            it.setCancelable(false)
            it.window?.setBackgroundDrawableResource(android.R.color.transparent)
        }

        include_toolbar.toolbar.title = "Your Orders"
        include_toolbar.toolbar.subtitle = "Wait for the best meal"

    }

//    override fun onTransactionSuccess(transactionResponse: TransactionResponse) {
//        if (transactionResponse.data.isNullOrEmpty()) {
//            layout_empty_order.visibility = View.VISIBLE
//            layout_order.visibility = View.GONE
//            include_toolbar.visibility = View.GONE
//
//        } else {
//            for (a in transactionResponse.data.indices) {
//                if (transactionResponse.data[a].status.equals("ON_DELIVERY", true)
//                    || transactionResponse.data[a].status.equals("PENDING", true)
//                ) {
//                    inProgressList?.add(transactionResponse.data[a])
//                } else if (transactionResponse.data[a].status.equals("DELIVERY", true)
//                    || transactionResponse.data[a].status.equals("CANCELLED", true)
//                    || transactionResponse.data[a].status.equals("SUCCESS", true)
//                ) {
//                    pastOrderList?.add(transactionResponse.data[a])
//                }
//            }
//
//            val sectionPagerAdapter = SectionPagerAdapter(childFragmentManager)
//            sectionPagerAdapter.setData(inProgressList, pastOrderList)
//            viewPager.adapter = sectionPagerAdapter
//            tablayout.setupWithViewPager(viewPager)
//        }
//    }
//
//
//    override fun onTransactionFailed(message: String) {
//        Toast.makeText(activity, message, Toast.LENGTH_SHORT).show()
//    }
//
//    override fun showLoading() {
//        progressDialog?.show()
//    }
//
//    override fun dismissLoading() {
//        progressDialog?.dismiss()
//    }
}