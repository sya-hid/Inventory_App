package com.syarifhidayatullah.myapplication.ui.order.add


import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.syarifhidayatullah.myapplication.R
import com.syarifhidayatullah.myapplication.model.dummy.ListModel
import kotlinx.android.synthetic.main.item_list.view.*

class ListAdapter(
    private val listData: List<ListModel>,
    private val itemAdapterCallback: ItemAdapterCallback
) : RecyclerView.Adapter<ListAdapter.ViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ListAdapter.ViewHolder {
        val layoutInflater = LayoutInflater.from(parent.context)
        val view = layoutInflater.inflate(R.layout.item_list, parent, false)
        return ViewHolder(view)
    }

    override fun getItemCount(): Int {
        return listData.size
    }

    override fun onBindViewHolder(holder: ListAdapter.ViewHolder, position: Int) {
        holder.bind(listData[position], itemAdapterCallback)
//        holder.itemView.btn_add.setOnClickListener {
//
//        }
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        fun bind(data: ListModel, itemAdapterCallback: ItemAdapterCallback) {
//            itemView.apply {
//                txvNama.text=data.food.name
//                txvPrice.formatPrice(data.food.price.toString())
//                txvStatus.text=data.status
//                txvDate.text=data.createdAt?.converLongToTime("MMM dd , HH.mm ")
//                Glide.with(context)
//                    .load(data.food.picturePath)
//                    .into(imvFood)
//                itemView.setOnClickListener { itemAdapterCallback.onClick(it,data)  }
//            }


            itemView.apply {
                txvName.text = data.name
                txvJenis.text = data.jenis
                txvJumlah.text = data.jumlah.toString()

cekJumlah()
                btn_min.setOnClickListener {
                    val jumlah = txvJumlah.text.toString()
                    val total = jumlah.toInt() - 1
                    txvJumlah.text = total.toString()
                    cekJumlah()
                }
                btn_add.setOnClickListener {
                    val jumlah = txvJumlah.text.toString()
                    val total = jumlah.toInt() + 1
                    txvJumlah.text = total.toString()
                    cekJumlah()
                }


//                itemView.setOnClickListener { itemAdapterCallback.onClick(it, data) }
            }

        }

        private fun cekJumlah() {
            val jlh = itemView.txvJumlah.text.toString()

            if (jlh.toInt() < 2) {
                itemView.btn_min.visibility = View.GONE
            }
            if (jlh.toInt() > 1) {
                itemView.btn_min.visibility = View.VISIBLE
            }
        }
    }

    interface ItemAdapterCallback {
        fun onClick(v: View, data: ListModel)
    }
}