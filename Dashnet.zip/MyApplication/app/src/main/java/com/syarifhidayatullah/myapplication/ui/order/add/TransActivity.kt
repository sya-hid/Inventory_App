package com.syarifhidayatullah.myapplication.ui.order.add

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.zxing.Result
import com.syarifhidayatullah.myapplication.R
import com.syarifhidayatullah.myapplication.model.dummy.ListModel
import kotlinx.android.synthetic.main.activity_trans.*
import me.dm7.barcodescanner.core.IViewFinder
import me.dm7.barcodescanner.zxing.ZXingScannerView

class TransActivity : AppCompatActivity(),ZXingScannerView.ResultHandler,ListAdapter.ItemAdapterCallback {
    private lateinit var mScannerView: ZXingScannerView
    private var dataList:ArrayList<ListModel> = ArrayList()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_trans)
        initScannerView()
        initDummy()

        var adapter=ListAdapter(dataList, this)
        var layoutManager:RecyclerView.LayoutManager = LinearLayoutManager(this)
        rcvList.layoutManager=layoutManager
        rcvList.adapter=adapter

btnSimpan.setOnClickListener {
    Toast.makeText(this, edtNamaTeknisi.text.toString()+dataList[0].name+dataList[0].jumlah, Toast.LENGTH_SHORT).show()

}
    }

    private fun initDummy() {
        dataList= ArrayList()
        dataList.add(ListModel("Radio","Bullet M5","",1))
        dataList.add(ListModel("Wifi","TP-Link","",2))
        dataList.add(ListModel("Router","Router Board 250 GS","",4))
        dataList.add(ListModel("Modem","Fiberhome HG G2 BC","",3))
    }

    private fun initScannerView() {
        mScannerView=object : ZXingScannerView(this){
            override fun createViewFinderView(context: Context?): IViewFinder {
                return super.createViewFinderView(context!!)
            }
        }
        mScannerView.setAutoFocus(true)
        mScannerView.setResultHandler(this)
        frame_layout_camera.addView(mScannerView)
    }
    override fun onStart() {
        mScannerView.startCamera()
        doRequestPermission()
        super.onStart()
    }
    private fun doRequestPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(arrayOf(Manifest.permission.CAMERA), 100)
            }
        }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        when (requestCode) {
            100 -> {
                initScannerView()
            }
            else -> {
                /* nothing to do in here */
            }
        }
    }
    override fun onPause() {
        mScannerView.stopCamera()
        super.onPause()
    }
    override fun handleResult(p0: Result?) {
        Toast.makeText(this, p0.toString(), Toast.LENGTH_SHORT).show()
    }

    override fun onClick(v: View, data: ListModel) {

        Toast.makeText(this, data.name, Toast.LENGTH_SHORT).show()
    }


}