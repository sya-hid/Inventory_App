package com.syarifhidayatullah.myapplication.ui.order.pastorder

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.syarifhidayatullah.myapplication.R
import com.syarifhidayatullah.myapplication.model.dummy.HomeNewTasteModel
import kotlinx.android.synthetic.main.fragment_pastorder.*
import kotlinx.android.synthetic.main.fragment_profile_account.*


class PastOrderFragment : Fragment(),PastOrderAdapter.ItemAdapterCallback{
 //   private var menuArrayList: ArrayList<ProfileMenuModel> = ArrayList()

    private var adapter: PastOrderAdapter?=null
    var pastOrderList:ArrayList<HomeNewTasteModel>? = ArrayList()
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
       val root=inflater.inflate(R.layout.fragment_pastorder, container, false)
        return root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
     //   pastOrderList = arguments?.getParcelableArrayList("data")

        if (!pastOrderList.isNullOrEmpty()){
            adapter= PastOrderAdapter(pastOrderList!!,this)
            val layoutManager=LinearLayoutManager(activity)
            rcvOrderList.layoutManager=layoutManager

            rcvOrderList.adapter=adapter
        }
    }
    override fun onClick(v: View, data: HomeNewTasteModel) {
     //   Toast.makeText(activity, data.food.name, Toast.LENGTH_SHORT).show()
    }


}